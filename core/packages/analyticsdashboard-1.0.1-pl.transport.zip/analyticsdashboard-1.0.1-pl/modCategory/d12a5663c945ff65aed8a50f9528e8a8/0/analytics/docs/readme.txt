--------------------
Extra: Analytics Dashboard widget
--------------------
Version: 1.0.0
Since: December 9th, 2011
Author: Wieger Sloot, Sterc <wieger@sterc.nl>

A custom MODx dashboard widget that will show data from Google Analytics.

You need a Google Analytics account to use this plugin.


--------------------
Features
--------------------

- Check your site’s statistics from within MODx
- Information about your site’s visitors, traffic sources, top content, goals and keywords
- Visitors and goals are displayed in graphs
- Traffic Sources are displayed in a pie chart