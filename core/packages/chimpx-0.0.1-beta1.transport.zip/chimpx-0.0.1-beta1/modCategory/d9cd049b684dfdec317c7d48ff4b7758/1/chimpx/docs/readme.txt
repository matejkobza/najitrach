----------------------------------------
Chimpx
----------------------------------------
Version: 0.0.1 beta 1
Author: Romain Tripault // Melting Media <romain@melting-media.com>
----------------------------------------

A MailChimp integration for MODx Revolution.

Feel free to suggest ideas/improvements or report bugs on GitHub:
https://github.com/meltingmedia/chimpx/issues